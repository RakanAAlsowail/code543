Step 1 : Download the dataset from the given links :   

         https://www.kaggle.com/datasets/balraj98/massachusetts-buildings-dataset.

         https://www.kaggle.com/datasets/balraj98/deepglobe-road-extraction-dataset?select=train.  
	
	 https://www.kaggle.com/datasets/balraj98/deepglobe-land-cover-classification-dataset?select=train.

	 https://www.kaggle.com/datasets/enddl22/deepnir-nir-rgb-sen12ms-dataset.

Step 2 : Open the python application and enter the code.

Step 3 : Enter the path of the downloaded dataset.

Step 4 : Finally execute the code.

Step 5 : The output will display in terminal.